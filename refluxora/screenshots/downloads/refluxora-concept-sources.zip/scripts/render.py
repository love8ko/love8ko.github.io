"""Render deterministic, explicitly labelled concept assets; never export a release pack."""
from pathlib import Path
import functools, http.server, json, threading, zipfile, struct, hashlib, os
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / 'site'
CHROME = os.environ.get('REFLUXORA_CHROME')
if not CHROME:
    cached=sorted((Path.home()/'Library/Caches/ms-playwright').glob('chromium-*/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'))
    CHROME=str(cached[-1]) if cached else None

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args): pass

def serve():
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(SITE)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    return server,f'http://127.0.0.1:{server.server_port}'

def main():
    (ROOT/'qa').mkdir(exist_ok=True)
    data=json.loads((SITE/'gallery.json').read_text())
    assert all(f['readiness']=='concept' for s in data['series'] for f in s['frames']), 'This renderer is for concept review only.'
    for folder in ('originals','previews','downloads'): (SITE/folder).mkdir(exist_ok=True)
    server,url=serve()
    try:
      with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=CHROME)
        context=browser.new_context(viewport={'width':440,'height':956},device_scale_factor=3)
        page=context.new_page();page.goto(url+'/index.html',wait_until='networkidle')
        for series in data['series']:
          for frame in series['frames']:
            page.evaluate("""f=>{document.body.replaceChildren(window.RefluxoraLayout(f));document.body.style.margin='0';}""",frame)
            page.evaluate("""async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode()));}""")
            page.locator('.art').screenshot(path=str(SITE/frame['original']),omit_background=False)
            page.locator('.art').screenshot(path=str(SITE/frame['preview']),type='jpeg',quality=90,scale='css')
            png=(SITE/frame['original']).read_bytes();w,h=struct.unpack('>II',png[16:24]);assert (w,h)==(1320,2868);assert png[25]==2, f'Expected RGB PNG, color type {png[25]}'
            print(frame['id'],w,h,hashlib.sha256(png).hexdigest()[:12],flush=True)
        sheet=browser.new_page(viewport={'width':1056,'height':1660},device_scale_factor=1)
        sheet.goto(url+'/index.html',wait_until='networkidle')
        sheet.evaluate("""data=>{
          document.head.querySelectorAll('link[rel=stylesheet]').forEach(x=>x.remove());
          const style=document.createElement('style');style.textContent='*{box-sizing:border-box}body{margin:0;background:#f5f1ea;color:#18524f;font-family:-apple-system,sans-serif;padding:34px}h1{font-size:32px;letter-spacing:-1px;margin:0 0 8px}p{font-size:13px;margin:0 0 26px;color:#65786e}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}figure{margin:0}figcaption{font-size:16px;font-weight:600;margin:0 0 10px}img{width:100%;display:block;border-radius:10px}footer{font-size:12px;margin-top:22px}';document.head.append(style);
          document.body.replaceChildren();const h=document.createElement('h1');h.textContent='Refluxora · First three / A + B';const lead=document.createElement('p');lead.textContent='Human first above · Product first below · Design concepts, not for App Store';document.body.append(h,lead);
          const grid=document.createElement('div');grid.className='grid';for(const s of data.series)for(const f of s.frames){const fig=document.createElement('figure'),cap=document.createElement('figcaption'),img=document.createElement('img');cap.textContent=f.id+' · '+s.prefix;img.src=f.preview;fig.append(cap,img);grid.append(fig);}document.body.append(grid);const footer=document.createElement('footer');footer.textContent='Choose your frames: A01, B02, A03… · English (US) · '+data.version;document.body.append(footer);
        }""",data)
        sheet.evaluate('async()=>{await Promise.all([...document.images].map(i=>i.decode()))}')
        sheet.screenshot(path=str(SITE/'comparison.png'),full_page=True)
        browser.close()
    finally: server.shutdown();server.server_close()
    for series in data['series']:
      with zipfile.ZipFile(SITE/'downloads'/f"refluxora-{series['prefix']}-concepts.zip",'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('READ-ME.txt','DESIGN CONCEPTS — NOT FOR APP STORE\nThese screens are designed examples, not captures of the released app.\nUse for visual review only. Replace with approved native screens before release.\n')
        for f in series['frames']:z.write(SITE/f['original'],Path(f['original']).name)
    receipt={'version':data['version'],'status':'concept','frames':[{'id':f['id'],'sha256':hashlib.sha256((SITE/f['original']).read_bytes()).hexdigest(),'dimensions':[1320,2868],'color':'RGB','alpha':False} for s in data['series'] for f in s['frames']]}
    (ROOT/'qa'/'exports.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
