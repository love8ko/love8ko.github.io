"""Prepare C/D cast comparison from the approved A-direction story and new photos."""
from pathlib import Path
import json,copy,hashlib,subprocess,shutil
R=Path(__file__).resolve().parents[1];S=R/'site'
previous=json.loads((R/'scripts/storyboard_v3.json').read_text())
d={'version':'concept-2026-09-11.3','locale':'en-US','status':'design-concepts-not-for-app-store','series':[]}
for prefix,character in [('C','Male lead · About 45'),('D','Female lead · About 40')]:
 series={'prefix':prefix,'name':character,'description':'Same three situations. Same composition. One consistent character.','frames':[]}
 for i,stem in enumerate(['night','restaurant','clinic'],1):
  f=copy.deepcopy(previous['series'][0]['frames'][i-1]);id=f'{prefix}{i:02}';name=f'{id}-{stem}'
  f.update(id=id,series=prefix,character=character,asset=f'assets/v3/{name}.jpg',original=f'originals/{id}.png',preview=f'previews/{id}.jpg',prompt=f'prompts/v3/{name}.txt',generationMethod='Built-in ImageGen with within-series identity references + deterministic HTML/CSS scene composition',characterReference=f'sources/v3/{prefix}01-night.png',sourceScreenshot=None,releaseApproved=False)
  f['ui']['title']='Refluxora';f['ui']['label']='AI explanation · Example'
  if i==1:f['scene']='The lead sits awake at the edge of the bed while their partner sleeps; a bedside clock and small phone establish the interrupted night.';f['proofLabel']='ONE STEP TO CONSIDER';f['proofDiagram']={'start':'meal','duration':'3 hours','end':'bed'}
  if i==2:f['scene']='A couple points to a dish in an illustrated menu while a waiter takes their order; no food has been served.';f['foodAsset']='assets/v3/salmon-cutout.png';f['proofLabel']='ONE CHANGE TO CONSIDER'
  if i==3:f['scene']='Just after an appointment, a doctor passes the lead a report in a clinic; the patient checks the explanation on a phone.';f['proofLabel']='YOUR REPORT, EXPLAINED';f['reportPlacement']={'--paper-left':'47%' if prefix=='C' else '40.5%','--paper-top':'52.2%' if prefix=='C' else '55.1%','--paper-width':'22%' if prefix=='C' else '23%','--paper-transform':'rotate(-6deg) skewX(12deg)' if prefix=='C' else 'rotate(-7deg) skewX(10deg)'}
  series['frames'].append(f)
 d['series'].append(series)
(S/'gallery.json').write_text(json.dumps(d,indent=2)+'\n')
m=copy.deepcopy(d);m.update(authorization='Owner approved six C/D concepts, same A direction with male/female leads, scene recognition and larger type.',publication='https://love8ko.github.io/refluxora/screenshots/',archive='history/v2/',sourceAssets=[],research=previous.get('research',{}),generator={'tool':'built-in ImageGen','modelVersion':'Not exposed; Imagen 2.5 not selectable.'},castingNote='Two creative audience hypotheses, not measured demographics or actual patient testimonials.')
(S/'assets/v3').mkdir(parents=True,exist_ok=True)
for series in d['series']:
 for f in series['frames']:
  p=R/'sources/v3'/Path(f['asset']).with_suffix('.png').name
  if p.exists():
   subprocess.run(['sips','-s','format','jpeg','-s','formatOptions','96',str(p),'--out',str(S/f['asset'])],check=True,capture_output=True)
   m['sourceAssets'].append({'file':str(p.relative_to(R)),'prompt':f['prompt'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identityReference':f['characterReference'] if f['position']!='01' else None})
p=R/'sources/v3/salmon-cutout.png'
if p.exists():
 shutil.copy2(p,S/'assets/v3/salmon-cutout.png');m['sourceAssets'].append({'file':'sources/v3/salmon-cutout.png','prompt':'prompts/v3/salmon-cutout.txt','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'alpha':'True transparency; preserved unchanged','sharedBy':['C02','D02']})
(S/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('C/D data ready;',len(m['sourceAssets']),'assets present')
