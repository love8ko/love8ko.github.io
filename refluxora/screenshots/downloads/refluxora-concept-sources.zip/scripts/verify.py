"""Exercise review behavior, export contracts and explicit concept boundaries."""
from pathlib import Path
import json, struct, zipfile, sys, urllib.request
from playwright.sync_api import sync_playwright, expect
from render import serve, ROOT, SITE, CHROME

def main():
    public=sys.argv[1] if len(sys.argv)>1 else None
    server,url=(None,public.rstrip('/')) if public else serve()
    errors=[];checks=[]
    try:
      with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=CHROME)
        desktop=browser.new_context(viewport={'width':1440,'height':1150})
        page=desktop.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url+'/',wait_until='networkidle');page.wait_for_function('window.galleryReady === true')
        expect(page.locator('.series')).to_have_count(2);expect(page.locator('.shot')).to_have_count(6)
        assert page.locator('html').get_attribute('lang')=='en'
        assert page.locator('.frame-stage').all_text_contents()==['Design concept']*6
        assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
        page.screenshot(path=str(ROOT/'qa'/('public-desktop.png' if public else 'desktop.png')),full_page=True)
        page.locator('[data-id=C01]').click();expect(page.locator('#viewer')).to_be_visible()
        expect(page.locator('#viewer-title')).to_have_text('C01');expect(page.locator('#viewer-status')).to_contain_text('not for App Store')
        assert page.locator('#download').get_attribute('href').split('?')[0]=='originals/C01.png'
        with page.expect_download() as event:page.locator('#download').click()
        download=event.value;download.save_as(ROOT/'qa'/'download-C01.png');assert (ROOT/'qa'/'download-C01.png').stat().st_size>100000
        page.keyboard.press('ArrowRight');expect(page.locator('#viewer-title')).to_have_text('C02')
        for _ in range(8):
          page.keyboard.press('Tab');assert page.evaluate("document.querySelector('#viewer').contains(document.activeElement)")
        page.keyboard.press('Escape');expect(page.locator('#viewer')).not_to_be_visible();expect(page.locator('[data-id=C01]')).to_be_focused()
        checks+=['six concepts / two series','English document','full-size download','arrow navigation','focus containment and return','Escape closes modal']
        mobile=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
        m=mobile.new_page();m.on('pageerror',lambda e:errors.append(str(e)));m.goto(url+'/',wait_until='networkidle');m.wait_for_function('window.galleryReady === true')
        assert m.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
        assert m.locator('.row').first.evaluate('(e)=>e.scrollWidth>e.clientWidth')
        m.screenshot(path=str(ROOT/'qa'/('public-mobile.png' if public else 'mobile.png')),full_page=True)
        m.locator('[data-id=C01]').click()
        m.evaluate('''()=>{const target=document.querySelector('#viewer-body');const start=new Touch({identifier:1,target,clientX:280,clientY:300});target.dispatchEvent(new TouchEvent('touchstart',{touches:[start]}));const end=new Touch({identifier:1,target,clientX:100,clientY:305});target.dispatchEvent(new TouchEvent('touchend',{changedTouches:[end]}));}''')
        expect(m.locator('#viewer-title')).to_have_text('C02')
        checks+=['mobile no page overflow','horizontal rows','touch swipe changes frame']
        # Failed full-size image has an explicit message and a direct retry link.
        page.route('**/originals/C03.png*',lambda route:route.abort());page.locator('[data-id=C03]').click();expect(page.locator('#viewer-body')).to_contain_text('Image unavailable');expect(page.locator('#original')).to_be_visible();page.keyboard.press('Escape')
        checks.append('failed original displays recovery')
        for sub in ['archive.html','comparison.html','capture-brief.html','readability.html','history/v2/']:
          page.goto(url+'/'+sub,wait_until='networkidle');assert page.title();assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
        assert not errors,errors
        checks+=['rationale / comparison / capture handoff','no JavaScript exceptions']
        data=json.loads((SITE/'gallery.json').read_text())
        served=desktop.request.get(url+'/gallery.json').json()
        assert served['version']==data['version'], 'The public gallery has not updated yet.'
        if not public:
          for width in [180,220]:
            small=browser.new_page(viewport={'width':width,'height':600})
            small.goto(url+'/',wait_until='networkidle')
            for s in data['series']:
              for f in s['frames']:
                small.evaluate('f=>{document.body.replaceChildren(window.RefluxoraLayout(f));}',f)
                small.evaluate('async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode()))}')
                assert small.locator('.proof-focus').inner_text()==small.locator('.ui-focus').inner_text()==f['ui']['focus']
                assert 5<=len(f['ui']['focus'].split())<=10
                assert ' '.join(small.locator('.audience-tags').inner_text().split())=='GERD • ACID REFLUX'
                assert small.locator('.audience-tags').bounding_box()['y']+small.locator('.audience-tags').bounding_box()['height']<small.locator('.art-head').bounding_box()['y']
                sub=small.locator('.art-subline').evaluate('(e)=>({font:parseFloat(getComputedStyle(e).fontSize),line:parseFloat(getComputedStyle(e).lineHeight),height:e.getBoundingClientRect().height})')
                assert 96<=sub['font']*1320/width<=110,(f['id'],'subline size',sub)
                assert sub['height']<=sub['line']*2+1,(f['id'],'more than two subline lines')
                if f['position']=='01':
                  assert small.locator('.ui-card .timing-diagram').inner_text()==small.locator('.proof-card .timing-diagram').inner_text()
                if f['position']=='02':
                  assert small.locator('.ui-dish').get_attribute('src')==small.locator('.hero-dish').get_attribute('src')==f['foodAsset']
                if f['position']=='03':
                  assert small.locator('.report-value').inner_text()==small.locator('.aet-value').inner_text()=='7.2%'
                bounds=small.evaluate('''()=>{const b=s=>document.querySelector(s).getBoundingClientRect().toJSON();return {art:b('.art'),head:b('.art-head'),proof:b('.proof-card'),focus:b('.ui-focus'),explanation:b('.ui-explanation')};}''')
                assert bounds['head']['right']<=width, (f['id'],'headline edge')
                assert bounds['proof']['bottom']<bounds['art']['bottom'], (f['id'],'proof bottom')
                assert bounds['focus']['bottom']<bounds['proof']['top'], (f['id'],'proof obscures interface result',bounds)
                small.locator('.art').screenshot(path=str(ROOT/'qa'/f"{f['id']}-{width}.png"))
            small.close()
          checks+=['180/220 px render inspected','proof exactly matches interface (5–10 words)','no proof/headline clipping or overlap with interface result']
          checks+=['sublines 96–110 px equivalent and at most two lines','same dish, timing diagram and AET inside/outside device']
        for s in data['series']:
          for f in s['frames']:
            raw=(SITE/f['original']).read_bytes();assert struct.unpack('>II',raw[16:24])==(1320,2868);assert raw[25]==2
            for key in ['original','preview','asset']:
              response=desktop.request.get(url+'/'+f[key]);assert response.status==200,(key,response.status)
          archive=SITE/'downloads'/f"refluxora-{s['prefix']}-concepts.zip"
          with zipfile.ZipFile(archive) as z: assert z.testzip() is None;assert 'NOT FOR APP STORE' in z.read('READ-ME.txt').decode()
          response=desktop.request.get(url+'/downloads/'+archive.name);assert response.status==200
        checks+=['PNG 1320×2868 RGB without alpha','all images return HTTP 200','both concept ZIPs valid and downloadable']
        for path in ['downloads/refluxora-concept-sources.zip','history/v2/gallery.json','history/v2/originals/A01.png','comparison.png']:
          assert desktop.request.get(url+'/'+path).status==200,path
        browser.close()
    finally:
      if server:server.shutdown();server.server_close()
    receipt={'url':url,'checks':checks,'errors':errors}
    (ROOT/'qa'/('public-checks.json' if public else 'local-checks.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
