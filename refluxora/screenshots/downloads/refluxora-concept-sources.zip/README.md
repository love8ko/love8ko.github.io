# Refluxora — C / D character comparison

Public gallery: https://love8ko.github.io/refluxora/screenshots/

Six English concepts develop the approved human-led A direction:

- C01–C03: one consistent male lead, about 45.
- D01–D03: one consistent female lead, about 40.
- Same stories, copy, device composition, illustrated timing result and dish asset.
- Order: interrupted sleep → choosing a restaurant order → receiving a reflux report after an appointment.

The characters are creative hypotheses, not measured customer demographics. The owner authorized designed interface examples; no app code or simulator changes are part of this project.

## Assets and review

`site/` contains the active C/D gallery, pair comparison, actual-size 180/220 px review, originals and ZIPs. Previous A/B is preserved at `site/history/v2/`; the first implementation remains at `site/history/v1/`.

`sources/v3/` preserves six new photographs and one transparent salmon cutout. Exact prompts, identity references and iteration notes are in `site/prompts/v3/`. The shared dish image is reused inside and outside the phone. Night scenes share the same deterministic meal → 3 hours → bed component between UI and proof. Report data and result text agree inside and outside the device.

`site/manifest.json` records each frame, photo, hash, source, prompt, character reference and concept status. Built-in ImageGen was used. Its underlying model version is not exposed; the assets are not represented as Imagen 2.5 output.

## Reproduction

Install `requirements.txt`, then run `python -m playwright install chromium`.

1. `python scripts/prepare_v3.py` prepares source assets and C/D metadata.
2. `python scripts/review_docs.py` builds the English review documentation.
3. `python scripts/render.py` renders PNGs, previews, contact sheet and C/D ZIPs.
4. `python scripts/package.py` bundles editable sources.
5. `python scripts/verify.py` verifies the local gallery, image contracts and small-size text.

The renderer uses the macOS Playwright cache when present; `REFLUXORA_CHROME` overrides the executable. In this workspace, run using `../../scripts/rag/.venv/bin/python` from this directory.

Historical preparation scripts are kept for provenance; `prepare_v3.py` is the current entry point. The source ZIP excludes historical series and previous source photographs.

Exports are 1320 × 2868 RGB PNG without transparency. Sublines are 96–99 px. Owner-requested GERD • ACID REFLUX topic markers appear under the brand. Final product correspondence and character selection still require owner review before App Store submission. The AET value of 7.2% is synthetic with no diagnostic verdict. The physician shown in the scene is not an endorsement or live consultation feature.

Publishing uses the isolated `love8ko/love8ko.github.io` checkout and only updates `refluxora/screenshots/`. Shared Design / Flow / Screenshots navigation is preserved. QA receipts and actual-size images are in `qa/`.
