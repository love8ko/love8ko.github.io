# Refluxora App Store V2 — first three

Six English design concepts: A01–A03 (Human), B01–B03 (Product). User explicitly authorized designed interface examples while production work continues. No native app code or simulator state changed.

Public target: https://love8ko.github.io/refluxora/screenshots/

- `site/`: gallery, comparison, rationale, capture handoff, concepts and review ZIPs.
- `sources/`: preserved full-resolution original photographs.
- `site/prompts/`: original prompts and prepared production prompts.
- `site/manifest.json`: claims, synthetic examples, provenance, dimensions and readiness.
- `scripts/render.py`: deterministic composition export using Playwright; defaults to concept mode.
- `scripts/verify.py`: gallery interactions and image/link checks.
- `qa/`: local and public verification evidence.

Render: `../../scripts/rag/.venv/bin/python scripts/render.py` from this directory.
Verify: `../../scripts/rag/.venv/bin/python scripts/verify.py` from this directory.

All v1 PNGs and ZIPs are DESIGN CONCEPTS, NOT FOR APP STORE. No release ZIP exists. Replace designed UI with approved native captures before App Store use. Synthetic B12 values are illustrative, not a universal reference range.

Publishing uses an isolated checkout of `love8ko/love8ko.github.io`; only `refluxora/screenshots/` and navigation links in the existing index/design/flow pages are changed. Do not copy the dirty app repository into the publishing checkout.

Standalone setup: install Python dependencies from `requirements.txt`, then `python -m playwright install chromium`. The renderer uses the existing macOS Playwright browser cache when available; `REFLUXORA_CHROME` can select a browser executable.
After standalone setup, run `python scripts/render.py` and `python scripts/verify.py` from the extracted source directory.
