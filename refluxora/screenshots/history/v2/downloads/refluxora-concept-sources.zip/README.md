# Refluxora App Store V2 — revised first three

Public review: https://love8ko.github.io/refluxora/screenshots/

Six English concepts: A01–A03 (person and situation), B01–B03 (input and explanation).
Order: nighttime heartburn → menu before ordering → esophageal pH report.
The owner authorized designed interface examples while the production app is developed in parallel. No app code or simulator changes are part of this project.

## Contents

- `site/`: current gallery, comparison, 180/220 px review, rationale, originals and ZIPs.
- `site/history/v1/`: preserved first version with its original images and packages.
- `sources/v2/`: three new, unaltered ImageGen photographs.
- `site/prompts/01-night.txt`, `02-restaurant.txt`, `03-report.txt`: exact generation prompts.
- `site/layout.js`, `site/product.css`: deterministic typography, UI, demo values, metallic device frame and enlarged result.
- `site/manifest.json`: story, claims, sources, asset hashes and readiness.
- `qa/`: dimensions, hashes, small-size renders and local/public browser receipts.

The generator was built-in ImageGen. Its model version is not exposed or selectable; the photographs are not claimed to use Imagen 2.5.

## Reproduce

Install `requirements.txt`, then `python -m playwright install chromium`.
Run `python scripts/render.py` and `python scripts/verify.py`.
The renderer can use the macOS Playwright cache; `REFLUXORA_CHROME` overrides the executable.
In this workspace the existing Python is `../../scripts/rag/.venv/bin/python` from this directory.

`prepare_v2.py` records the storyboard and converts preserved source photos to JPEG scene assets; `review_docs.py` builds the English rationale/handoff pages. `package.py` creates the source ZIP after rendering.

All PNGs are 1320 × 2868 RGB without alpha. These are design concepts for review. Validate the product examples against the approved app before App Store submission. The 7.2% AET value is synthetic, with no diagnostic verdict. The active series contains no B12 example; the historical version retains its original content.

Publishing uses the isolated checkout of `love8ko/love8ko.github.io`; update only `refluxora/screenshots/`. The common Design / Flow / Screenshots navigation remains in place. Do not copy unrelated app changes into the public repository.
