"""Bundle reproducible active concepts; history and export ZIPs are excluded."""
from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(R/'site/downloads/refluxora-concept-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['README.md','requirements.txt']:z.write(R/name,name)
 for folder in ['scripts','sources/v2','site']:
  for p in (R/folder).rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(R)
   if any(part in ['__pycache__','history','downloads','originals','previews'] for part in rel.parts) or p.name=='comparison.png':continue
   z.write(p,rel)
 z.writestr('READ-ME.txt','DESIGN CONCEPTS — NOT FOR APP STORE\nSee README.md for reproduction and source provenance.\n')
print('Source ZIP ready')
